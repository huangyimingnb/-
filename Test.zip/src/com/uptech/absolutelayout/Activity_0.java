package com.uptech.absolutelayout;

import java.io.IOException;

import com.uptech.absolutelayout.R;
import com.uptech.absolutelayout.Activity_1.DBConnection;
import com.uptech.absolutelayout.Activity_1.UserSchema;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Activity_0 extends Activity {
    /** Called when the activity is first created. */
	private Button Button_1;
	private Button Button_2;
	String e = "";
    DBConnection helper;
    public int id_this;
    public interface UserSchema {
        String TABLE_NAME = "Users";          //Table Name
        String ID = "_id";                    //ID
        String USER_NAME = "user_name";       //User Name
        String PASSWORD = "password";         //Password
        String TELEPHONE = "telephone";       //Phone Number
        String MAIL_ADDRESS = "mail_address"; //Mail Address
    }
    /** Called when the activity is first created. */
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Button_1 = (Button)findViewById(R.id.button_1);
        Button_2 = (Button)findViewById(R.id.button_2);
        final EditText mEditText01 = (EditText)findViewById(R.id.EditText01);
        final EditText mEditText02 = (EditText)findViewById(R.id.EditText02);
        
        //�������ݿ�DB�ͱ�Table:Users
        helper = new DBConnection(this);
        final SQLiteDatabase db = helper.getWritableDatabase(); 
        final String[] FROM = {   
            UserSchema.ID,
            UserSchema.USER_NAME,
            UserSchema.TELEPHONE,
            UserSchema.PASSWORD, 
            UserSchema.MAIL_ADDRESS
        };
        
        //��ת��ע���û�����
        Button_1.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				/*newһ��Intent���󣬲�ָ��class*/
				Bundle bundle = new Bundle();
				Intent intent = new Intent();
	   	   		intent.setClass(Activity_0.this, Activity_1.class); 
	   	        /*����Activity_1 �����ؽ��*/ 
	   	        startActivity(intent); 
			}
		});
        
        //���е�½�������ɹ�����ת����֮��ʾ������Ϣ
        Button_2.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				try {
					Runtime.getRuntime().exec("ioctl -d /dev/ledtest 0 1"); //LED2
					Runtime.getRuntime().exec("ioctl -d /dev/ledtest 0 3"); //LED4
				}
				catch(IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				String user_name = mEditText01.getText().toString();
				String password = mEditText02.getText().toString();
				if (user_name.equals(e) || password.equals(e)) {
					Toast.makeText(Activity_0.this, "�������û���������", Toast.LENGTH_LONG).show();
				}
				else {
					Cursor c = db.query("Users", FROM , "user_name='" + user_name + "'", null, null, null, null);
					c.moveToFirst();
					String password_this = c.getString(3);
					Bundle bundle = new Bundle();
					Intent intent1 = new Intent();
					if (password_this.equals(password)) {
		   	   			intent1.setClass(Activity_0.this, Activity_3.class); 
		   	   			startActivity(intent1); 
					}
					else 
						Toast.makeText(Activity_0.this, "�û��������벻��ȷ", Toast.LENGTH_LONG).show();
				}
			}
		});
    }
    
    //SQLiteOpenHelper-�������ݿ�PhoneBookDB��Table:Users
    public static class DBConnection extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "DB";
        private static final int DATABASE_VERSION = 1;
        private DBConnection(Context ctx) {
            super(ctx, DATABASE_NAME, null, DATABASE_VERSION);
        }
        public void onCreate(SQLiteDatabase db) {
            String sql = "CREATE TABLE " + UserSchema.TABLE_NAME + " (" 
            + UserSchema.ID  + " INTEGER primary key autoincrement, " 
            + UserSchema.USER_NAME + " text not null, " 
            + UserSchema.TELEPHONE + " text not null, " 
            + UserSchema.PASSWORD + " text not null, "
            + UserSchema.MAIL_ADDRESS + " text not null "+ ");";
            //Log.i("haiyang:createDB=", sql);
            db.execSQL(sql);    
        }
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // TODO Auto-generated method stub  
        }
    }
}