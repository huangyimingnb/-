package com.uptech.absolutelayout;

import com.google.zxing.WriterException;
import com.zxing.activity.CaptureActivity;
import com.zxing.encoding.EncodingHandler;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Activity_6 extends Activity { 
	private TextView resultTextView;
	private Button getin;

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_6);
        
        resultTextView = (TextView) this.findViewById(R.id.tv_scan_result);
        getin=(Button)findViewById(R.id.QR_getin);
        //ɨ��ʶ��-������ͷ
        Button scanBarCodeButton = (Button) this.findViewById(R.id.botton);
        scanBarCodeButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent openCameraIntent = new Intent(Activity_6.this,CaptureActivity.class);
				startActivityForResult(openCameraIntent, 0);
			}
		});
        getin.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				/*newһ��Intent���󣬲�ָ��class*/
				Bundle bundle = new Bundle();
				Intent intent = new Intent();
	   	   		intent.setClass(Activity_6.this, loginpritf.class); 
	   	     	startActivity(intent); 
			}
		});
    } 
    
    @Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		if (resultCode == RESULT_OK) {
			Bundle bundle = data.getExtras();
			String scanResult = bundle.getString("result");
			resultTextView.setText(scanResult);
		}
	}
}