package com.uptech.absolutelayout;

import java.io.IOException;

import com.uptech.absolutelayout.R;
import com.zxing.activity.CaptureActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Activity_3 extends Activity{
	private Button Button_1;
	private Button Button_2;
	private Button Button_3;
	private Button Button_4;
	
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
        
        Button_1 = (Button)findViewById(R.id.button1);
        Button_2 = (Button)findViewById(R.id.button2);
        Button_3 = (Button)findViewById(R.id.button3);
        Button_4 = (Button)findViewById(R.id.button4);
        
        
        //��ת����ͨ���Ž���
        Button_1.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				try {
					Runtime.getRuntime().exec("ioctl -d /dev/ledtest 1 1"); //LED2
					Runtime.getRuntime().exec("ioctl -d /dev/ledtest 1 3"); //LED4
					Runtime.getRuntime().exec("ioctl -d /dev/ledtest 0 4"); //������
				}
				catch(IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				/*newһ��Intent���󣬲�ָ��class*/
				Bundle bundle = new Bundle();
				Intent intent = new Intent();
	   	   		intent.setClass(Activity_3.this, Activity_4.class); 
	   	     	startActivity(intent); 
			}
		});
        
        //��ת��NFC���Ž���
        Button_2.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				/*newһ��Intent���󣬲�ָ��class*/
				Bundle bundle = new Bundle();
				Intent intent = new Intent();
	   	   		intent.setClass(Activity_3.this, Activity_5.class); 
	   	     	startActivity(intent); 
			}
		});
        
        //��ת��ɨ��ʶ�����
        Button_3.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				/*newһ��Intent���󣬲�ָ��class*/
				Bundle bundle = new Bundle();
				Intent intent = new Intent();
	   	   		intent.setClass(Activity_3.this, Activity_6.class); 
	   	     	startActivity(intent); 
			}
		});
        
        //��ת���û���������
        Button_4.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				/*newһ��Intent���󣬲�ָ��class*/
				Bundle bundle = new Bundle();
				Intent intent = new Intent();
	   	   		intent.setClass(Activity_3.this, Activity_7.class); 
	   	     	startActivity(intent); 
			}
		});
        
        //��ת�������¼����
      
        
	}
}
