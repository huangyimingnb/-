package com.uptech.absolutelayout;

import java.security.PublicKey;

import java.io.IOException;
import com.uptech.absolutelayout.R;
import com.weiqian.clientSocketThread.MessageListener;
import com.weiqian.clientSocketThread.clientSocketTools;
import com.weiqian.clientSocketThread.ClientSocketThread;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

public class Activity_5 extends Activity implements OnClickListener{
	private Button nfc_open,nfc_read,nfc_exit,getin;
	private ClientSocketThread clientSocketThread;
	//buffer�д���� server֡��ͨ���޸� buffer�е�������ʵ�ֶԲ���������źŵƵĿ���
	private byte[]buffer={(byte)0xFE,(byte)0xE0,0x08,0x32,0x72,0x00,0x02,0x0A}; //0x32��Ӧ�����������
	private byte[]data={(byte)0xFE,(byte)0xE0,0x08,0x32,0x72,0x00,0x02,0x0A};
	private EditText result;//may
	private MyHandler handler;
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
        setContentView(R.layout.nfc);
       nfc_open=(Button) findViewById(R.id.nfc_open);
       nfc_read=(Button) findViewById(R.id.nfc_read);
       nfc_exit=(Button) findViewById(R.id.nfc_exit);
       getin=(Button) findViewById(R.id.nfc_getin);
       nfc_exit.setOnClickListener(this);
       nfc_open.setOnClickListener(this);
       nfc_read.setOnClickListener(this);
       handler=new MyHandler();
	   result = (EditText) findViewById(R.id.nfc_result);
	   getin.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				/*newһ��Intent���󣬲�ָ��class*/
				Bundle bundle = new Bundle();
				Intent intent = new Intent();
	   	   		intent.setClass(Activity_5.this, loginpritf.class); 
	   	     	startActivity(intent); 
			}
		});
       
        //ʵ�����ͻ��� server�߳�
      	//���� ClinetSocketThread���getClientSocket()��������һ���߳��� server����ͨ��
      	new Thread(new Runnable(){
      		public void run() {
      			//server�ﶨ��port�̶�Ϊ6109
      			clientSocketThread = ClientSocketThread.getClientSocket(clientSocketTools.getLocalIpAddress(),6109);	
      			clientSocketThread.setListener(new MessageListener() {
					
					@Override
					public void Message(byte[] message, int message_len) {
						// TODO Auto-generated method stub
						System.arraycopy(message, 1, data, 0,4);
						String s = clientSocketTools.byte2hex(data,4);
						handler.sendMessage(handler.obtainMessage(100, clientSocketTools.byte2hex(data,4)));
						
					}
				});
      		}	
      	}).start();
	}
	
	
	public class MyHandler extends Handler{
		@Override
		public void handleMessage(Message msg){
			String res = msg.obj.toString();
			result.setText(res);
		}
	}
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
			//���Ĳ�ͬbutton��buffer���server֡�����Ʋ�ͬ�Ĳ���
				
			case R.id.nfc_open:
				buffer[3]=0x51;
				
				
				break;
			case R.id.nfc_read:
				buffer[3]=0x55;
				
				
				break;
			case R.id.nfc_exit:
				buffer[3]=0x53;
				
				
				break;
		
		}
		try {
			clientSocketThread.getOutputStream().write(buffer);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
