/** Automatically generated file. DO NOT MODIFY */
package com.uptech.absolutelayout;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}