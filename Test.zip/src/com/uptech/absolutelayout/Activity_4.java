package com.uptech.absolutelayout;

import java.io.IOException;


import com.uptech.absolutelayout.R;
import com.weiqian.clientSocketThread.clientSocketTools;
import com.weiqian.clientSocketThread.ClientSocketThread;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class Activity_4 extends Activity implements OnClickListener{
	private Button light_green,light_yellow,light_red,motor_right,motor_stop,motor_left,matrix,getin;
	private ClientSocketThread clientSocketThread;
	//buffer�д���� server֡��ͨ���޸� buffer�е�������ʵ�ֶԲ���������źŵƵĿ���
	private byte[]buffer={(byte)0xFE,(byte)0xE0,0x08,0x32,0x72,0x00,0x02,0x0A}; //0x32��Ӧ�����������
	
	@Override 
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_4);
        
        try {
			Runtime.getRuntime().exec("ioctl -d /dev/ledtest 1 4"); //������
		}
		catch(IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        light_green = (Button)findViewById(R.id.button1);
        motor_right = (Button)findViewById(R.id.button2);
        light_yellow = (Button)findViewById(R.id.button3);
        motor_stop = (Button)findViewById(R.id.button4);
        light_red = (Button)findViewById(R.id.button5);
        motor_left = (Button)findViewById(R.id.button6);
        matrix = (Button)findViewById(R.id.button7);
        light_green.setOnClickListener(this);
        motor_right.setOnClickListener(this);
        light_yellow.setOnClickListener(this);
        motor_left.setOnClickListener(this);
        light_red.setOnClickListener(this);
		motor_stop.setOnClickListener(this);
		matrix.setOnClickListener(this);
		getin=(Button)findViewById(R.id.simple_getin);
		getin.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				/*newһ��Intent���󣬲�ָ��class*/
				Bundle bundle = new Bundle();
				Intent intent = new Intent();
	   	   		intent.setClass(Activity_4.this, loginpritf.class); 
	   	     	startActivity(intent); 
			}
		});
        
        //ʵ�����ͻ��� server�߳�
      	//���� ClinetSocketThread���getClientSocket()��������һ���߳��� server����ͨ��
      	new Thread(new Runnable(){
      		public void run() {
      			//server�ﶨ��port�̶�Ϊ6109
      			clientSocketThread = ClientSocketThread.getClientSocket(clientSocketTools.getLocalIpAddress(),6109);				
      		}	
      	}).start();
	}

	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
			//���Ĳ�ͬbutton��buffer���server֡�����Ʋ���������źŵơ�����ͬ�Ĳ���
				//buffer[3]=0x44 ���ƽ�ͨ��
			case R.id.button1:
				buffer[3]=0x44;
				buffer[6]=0x24; //���̵�
				break;
			case R.id.button3:
				buffer[3]=0x44;
				buffer[6]=0x12; //���Ƶ�
				break;
			case R.id.button5:
				buffer[3]=0x44;
				buffer[6]=0x09; //�����
				break;	
				
				//buffer[3]=0x32 ���Ƶ��
			case R.id.button2:
				buffer[3]=0x32;
				buffer[6]=0x03; //�����ת
				motor_left.setEnabled(false);
				motor_stop.setEnabled(true);
				motor_right.setEnabled(false);
				break;
			case R.id.button4:
				buffer[3]=0x32;
				buffer[6]=0x01; //���ֹͣת��
				motor_left.setEnabled(true);
				motor_stop.setEnabled(false);
				motor_right.setEnabled(true);
				break;
			case R.id.button6:
				buffer[3]=0x32;
				buffer[6]=0x02; //�����ת
				motor_left.setEnabled(false);
				motor_stop.setEnabled(true);
				motor_right.setEnabled(false);
				break;
				
				//buffer[3]=0x12 ���Ƶ���
			case R.id.button7:
				buffer[3]=0x12;
				buffer[6]=0x01;
				motor_left.setEnabled(false);
				motor_stop.setEnabled(false);
				motor_right.setEnabled(false);
				break;	
		}
		try {
			clientSocketThread.getOutputStream().write(buffer);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
