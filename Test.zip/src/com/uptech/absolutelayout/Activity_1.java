package com.uptech.absolutelayout;

import com.google.zxing.WriterException;
import com.uptech.absolutelayout.R;
import com.zxing.encoding.EncodingHandler;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Toast;

public class Activity_1 extends Activity {
    OnClickListener listener_add = null;
    OnClickListener listener_clear = null;
    OnClickListener listener_view = null;
    Button button_add;
    Button button_clear;
    Button button_view;
    
    DBConnection helper;
    public int id_this;
    
    private boolean isOpenEye = false;
    private ImageView qrImgImageView;
    
    public interface UserSchema {
        String TABLE_NAME = "Users";          //Table Name
        String ID = "_id";                    //ID
        String USER_NAME = "user_name";       //User Name
        String PASSWORD = "password";         //Password
        String TELEPHONE = "telephone";       //Phone Number
        String MAIL_ADDRESS = "mail_address"; //Mail Address
    }
    /** Called when the activity is first created. */
    
    //ע�����������
    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_1);
        final EditText mEditText01 = (EditText)findViewById(R.id.EditText01);
        final EditText mEditText02 = (EditText)findViewById(R.id.EditText02);
        final EditText mEditText03 = (EditText)findViewById(R.id.EditText03);
        final EditText mEditText04 = (EditText)findViewById(R.id.EditText04);
        qrImgImageView = (ImageView) this.findViewById(R.id.image);
        
        //�������ݿ�DB�ͱ�Table:Users
        helper = new DBConnection(this);
        final SQLiteDatabase db = helper.getWritableDatabase(); 
        final String[] FROM = {   
            UserSchema.ID,
            UserSchema.USER_NAME,
            UserSchema.TELEPHONE,
            UserSchema.PASSWORD, 
            UserSchema.MAIL_ADDRESS
        };
        
        //����[Add]��ťʱ������һ������
        listener_add = new OnClickListener() {  
            public void onClick(View v) {
                ContentValues values = new ContentValues();
                values.put(UserSchema.USER_NAME, mEditText01.getText().toString());
                values.put(UserSchema.TELEPHONE, mEditText02.getText().toString());
                values.put(UserSchema.PASSWORD, mEditText03.getText().toString());
                values.put(UserSchema.MAIL_ADDRESS, mEditText04.getText().toString());
                SQLiteDatabase db = helper.getWritableDatabase();
                db.insert(UserSchema.TABLE_NAME, null, values);
                db.close();
                onCreate(savedInstanceState);
                mEditText01.setText("");
                mEditText02.setText("");
                mEditText03.setText("");
                mEditText04.setText(""); 
                Toast.makeText(Activity_1.this, "�û�ע��ɹ�", Toast.LENGTH_LONG).show();    
            }
        };
        
        //����[Clear]��ťʱ����ձ༭��
        listener_clear = new OnClickListener() {
            public void onClick(View v) {
                mEditText01.setText("");
                mEditText02.setText("");
                mEditText03.setText("");
                mEditText04.setText("");
            }
        };
        
        //����[View]��ťʱ����ʾ����
        listener_view = new OnClickListener() {
			public void onClick(View v) {
				if(!isOpenEye) {
                    isOpenEye = true;
                    //����ɼ�
                    mEditText03.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }else{
                    isOpenEye = false;
                    //���벻�ɼ�
                    mEditText03.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
			}
        };
        
        //�趨BUTTON0i,i=1,2,3,4��OnClickListener
        button_add = (Button)findViewById(R.id.Button02);
        button_add.setOnClickListener(listener_add); 
        button_clear = (Button)findViewById(R.id.Button01);
        button_clear.setOnClickListener(listener_clear);
        button_view = (Button)findViewById(R.id.Button00);
        button_view.setOnClickListener(listener_view);
        
        Button generateQRCodeButton = (Button) this.findViewById(R.id.button03);
        generateQRCodeButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				try {
					String contentString = mEditText01.getText().toString();
					if (!contentString.equals("")) {	
						Bitmap qrCodeBitmap = EncodingHandler.createQRCode(contentString, 350);
						qrImgImageView.setImageBitmap(qrCodeBitmap);
					}else {
						Toast.makeText(Activity_1.this, "������Ϣ����Ϊ��", Toast.LENGTH_SHORT).show();
					}	
				} catch (WriterException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
    }	
    
    //SQLiteOpenHelper-�������ݿ�DB��Table:Users
    public static class DBConnection extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "DB";
        private static final int DATABASE_VERSION = 1;
        private DBConnection(Context ctx) {
            super(ctx, DATABASE_NAME, null, DATABASE_VERSION);
        }
        public void onCreate(SQLiteDatabase db) {
            String sql = "CREATE TABLE " + UserSchema.TABLE_NAME + " (" 
            + UserSchema.ID  + " INTEGER primary key autoincrement, " 
            + UserSchema.USER_NAME + " text not null, " 
            + UserSchema.TELEPHONE + " text not null, " 
            + UserSchema.PASSWORD + " text not null, "
            + UserSchema.MAIL_ADDRESS + " text not null "+ ");";
            //Log.i("haiyang:createDB=", sql);
            db.execSQL(sql);    
        }
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // TODO Auto-generated method stub  
        }
    }
}